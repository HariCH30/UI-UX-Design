import { FunctionComponent } from "react";
import styles from "./MacBookPro141.module.css";

const MacBookPro141: FunctionComponent = () => {
  return (
    <div className={styles.macbookPro141}>
      <div className={styles.navbar}>
        <div className={styles.navbarChild} />
        <div className={styles.iconLogoutParent}>
          <img className={styles.iconLogout} alt="" src="/-icon-logout.svg" />
          <div className={styles.logout}>Logout</div>
        </div>
        <div className={styles.iconCogParent}>
          <img className={styles.iconCog} alt="" src="/-icon-cog.svg" />
          <div className={styles.settings}>Settings</div>
        </div>
        <div className={styles.iconUserIconParent}>
          <img
            className={styles.iconUserIcon}
            alt=""
            src="/-icon-user-icon.svg"
          />
          <div className={styles.logout}>Profile</div>
        </div>
        <div className={styles.iconVideoParent}>
          <img className={styles.iconVideo} alt="" src="/-icon-video.svg" />
          <div className={styles.continue}>Continue</div>
        </div>
        <div className={styles.iconMessageParent}>
          <div className={styles.iconMessage}>
            <img className={styles.vectorIcon} alt="" src="/vector.svg" />
          </div>
          <div className={styles.logout}>Messages</div>
        </div>
        <div className={styles.iconHomeParent}>
          <div className={styles.iconHome}>
            <img className={styles.vectorIcon1} alt="" src="/vector1.svg" />
          </div>
          <div className={styles.home}>Home</div>
        </div>
        <div className={styles.b}>B.</div>
      </div>
      <div className={styles.rectangleParent}>
        <div className={styles.groupChild} />
        <img
          className={styles.fotorAi20231113125551Icon}
          alt=""
          src="/fotorai2023111312555-1@2x.png"
        />
        <div className={styles.helloHariParent}>
          <b className={styles.helloHari}>Hello Hari!</b>
          <b className={styles.itsGoodTo}>Its good to see you again</b>
        </div>
      </div>
      <div className={styles.groupParent}>
        <div className={styles.iconArrowCircleDownParent}>
          <img
            className={styles.iconArrowCircleDown}
            alt=""
            src="/-icon-arrow-circle-down.svg"
          />
          <img className={styles.groupItem} alt="" src="/rectangle-3@2x.png" />
        </div>
        <img
          className={styles.iconNotificationsNone}
          alt=""
          src="/-icon-notifications-none.svg"
        />
        <div className={styles.seachBar}>
          <div className={styles.seachBarChild} />
          <b className={styles.searchForAnything}>Search for anything...</b>
          <img
            className={styles.iconMagnifyingGlass}
            alt=""
            src="/-icon-magnifying-glass.svg"
          />
        </div>
      </div>
      <div className={styles.rectangleGroup}>
        <div className={styles.groupInner} />
        <div className={styles.div}>6</div>
        <div className={styles.coursesCompleted}>
          <p className={styles.courses}>{`Courses `}</p>
          <p className={styles.courses}>Completed</p>
        </div>
      </div>
      <div className={styles.rectangleContainer}>
        <div className={styles.groupInner} />
        <div className={styles.div1}>4</div>
        <div className={styles.coursesInProgressContainer}>
          <p className={styles.courses}>Courses</p>
          <p className={styles.courses}>in Progress</p>
        </div>
      </div>
      <div className={styles.groupDiv}>
        <div className={styles.groupChild1} />
        <div className={styles.continueWrapper}>
          <div className={styles.continue1}>Continue</div>
        </div>
        <div className={styles.ellipseParent}>
          <div className={styles.ellipseDiv} />
          <div className={styles.div2}>75%</div>
        </div>
        <div className={styles.photography}>Photography</div>
        <div className={styles.byAlex}>by Alex</div>
        <img
          className={styles.emojiCameraWithFlash}
          alt=""
          src="/-emoji-camera-with-flash.svg"
        />
        <img
          className={styles.iconArrowCircleRightOutli}
          alt=""
          src="/-icon-arrow-circle-right-outline.svg"
        />
        <img
          className={styles.iconArrowCircleLeftOutlin}
          alt=""
          src="/-icon-arrow-circle-left-outline.svg"
        />
      </div>
      <div className={styles.coursesParent}>
        <div className={styles.courses2}>Courses</div>
        <div className={styles.allCoursesParent}>
          <div className={styles.allCourses}>All Courses</div>
          <div className={styles.logout}>Newest</div>
          <div className={styles.logout}>Top Rated</div>
          <div className={styles.logout}>Most Popular</div>
        </div>
      </div>
      <div className={styles.rectangleParent1}>
        <div className={styles.groupChild2} />
        <div className={styles.viewCourseWrapper}>
          <b className={styles.viewCourse}>View Course</b>
        </div>
        <div className={styles.parent}>
          <div className={styles.div3}>4.5</div>
          <div className={styles.h30m}>05h 30m</div>
          <div className={styles.videoEditing}>Video Editing</div>
          <div className={styles.byChristopher}>by Christopher</div>
          <img
            className={styles.movieFilmEditorLogoDesignIcon}
            alt=""
            src="/moviefilmeditorlogodesignvideoeditinglogoconceptfreevector-1@2x.png"
          />
          <img className={styles.iconClock} alt="" src="/-icon-clock.svg" />
          <img className={styles.iconStar} alt="" src="/-icon-star.svg" />
        </div>
      </div>
      <div className={styles.rectangleParent2}>
        <div className={styles.groupChild2} />
        <div className={styles.viewCourseWrapper}>
          <b className={styles.viewCourse}>View Course</b>
        </div>
        <div className={styles.group}>
          <div className={styles.div4}>4.7</div>
          <div className={styles.h00m}>05h 00m</div>
          <div className={styles.learnAdobe}>Learn Adobe</div>
          <div className={styles.byKlausMichaleson}>by Klaus Michaleson</div>
          <img className={styles.iconClock1} alt="" src="/-icon-clock.svg" />
          <img className={styles.iconStar1} alt="" src="/-icon-star.svg" />
          <img
            className={styles.download11}
            alt=""
            src="/download-1-1@2x.png"
          />
        </div>
      </div>
      <div className={styles.rectangleParent3}>
        <div className={styles.groupChild2} />
        <div className={styles.viewCourseWrapper}>
          <b className={styles.viewCourse}>View Course</b>
        </div>
        <div className={styles.container}>
          <div className={styles.div5}>5.0</div>
          <div className={styles.h00m1}>06h 00m</div>
          <div className={styles.learnCanvas}>Learn Canvas</div>
          <div className={styles.byDamon}>by Damon</div>
          <img className={styles.iconClock2} alt="" src="/-icon-clock.svg" />
          <img className={styles.iconStar2} alt="" src="/-icon-star.svg" />
          <img
            className={styles.download1Icon}
            alt=""
            src="/download-1@2x.png"
          />
        </div>
      </div>
      <div className={styles.rectangleParent4}>
        <div className={styles.groupChild2} />
        <div className={styles.viewCourseWrapper}>
          <b className={styles.viewCourse}>View Course</b>
        </div>
        <div className={styles.parent1}>
          <div className={styles.div4}>4.9</div>
          <div className={styles.h00m}>04h 30m</div>
          <div className={styles.learnAdobe}>Learn Photoshop</div>
          <div className={styles.byKlausMichaleson}>by Elena</div>
          <img className={styles.iconClock3} alt="" src="/-icon-clock.svg" />
          <img className={styles.iconStar3} alt="" src="/-icon-star.svg" />
          <img
            className={styles.download21}
            alt=""
            src="/download-2-1@2x.png"
          />
        </div>
      </div>
      <div className={styles.frameParent}>
        <div className={styles.learningHoursParent}>
          <div className={styles.logout}>{`Learning Hours  `}</div>
          <div className={styles.myCourses}>My Courses</div>
        </div>
        <div className={styles.yourStatistics}>Your Statistics</div>
        <div className={styles.weeklyParent}>
          <div className={styles.weekly}>Weekly</div>
          <div className={styles.iconArrowDown}>
            <img className={styles.vectorIcon2} alt="" src="/vector2.svg" />
          </div>
        </div>
      </div>
      <div className={styles.groupContainer}>
        <div className={styles.frameGroup}>
          <div className={styles.monParent}>
            <div className={styles.mon}>mon</div>
            <div className={styles.mon}>tue</div>
            <div className={styles.mon}>wed</div>
            <div className={styles.mon}>thur</div>
            <div className={styles.mon}>fri</div>
            <div className={styles.mon}>sat</div>
            <div className={styles.mon}>sun</div>
          </div>
          <div className={styles.parent2}>
            <div className={styles.logout}>5</div>
            <div className={styles.logout}>4</div>
            <div className={styles.logout}>3</div>
            <div className={styles.logout}>2</div>
            <div className={styles.logout}>1</div>
            <div className={styles.logout}>0</div>
          </div>
        </div>
        <img className={styles.groupChild6} alt="" src="/vector-1.svg" />
        <div className={styles.groupChild7} />
        <div className={styles.groupChild8} />
        <div className={styles.groupChild9} />
        <div className={styles.groupChild10} />
        <div className={styles.groupChild11} />
        <div className={styles.groupChild12} />
        <div className={styles.groupChild13} />
      </div>
      <div className={styles.rectangleParent5}>
        <div className={styles.groupChild14} />
        <div className={styles.learnEvenMore}>Learn Even More</div>
        <div
          className={styles.unlockPremiumFeatures}
        >{`Unlock premium features only for $9.99 per month.  `}</div>
        <div className={styles.getPremiumWrapper}>
          <div className={styles.logout}>Get Premium</div>
        </div>
        <img
          className={styles.isYourIdeaInnovative1Icon}
          alt=""
          src="/is-your-idea-innovative-1@2x.png"
        />
      </div>
    </div>
  );
};

export default MacBookPro141;
