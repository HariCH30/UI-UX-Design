import { FunctionComponent } from "react";
import styles from "./Desktop.module.css";

const Desktop: FunctionComponent = () => {
  return (
    <div className={styles.desktop}>
      <div className={styles.navbar}>
        <div className={styles.navbarChild} />
        <div className={styles.text}>
          <b className={styles.travelBlog}>Travel Blog</b>
          <div className={styles.menu}>
            <div className={styles.abour}>Abour</div>
            <div className={styles.abour}>Travel Tips</div>
            <div className={styles.abour}> Destinations</div>
            <div className={styles.abour}>Bookings</div>
            <img className={styles.vectorIcon} alt="" src="/vector.svg" />
          </div>
        </div>
      </div>
      <div className={styles.bannerArticle}>
        <img
          className={styles.bannerImageIcon}
          alt=""
          src="/banner-image@2x.png"
        />
        <div className={styles.text1}>
          <b className={styles.travelTheWorld}>Travel the World</b>
          <div className={styles.travelBlog}>In Label</div>
          <div className={styles.byTraveller}>By traveller</div>
        </div>
      </div>
      <div className={styles.sectionSideCard}>
        <div className={styles.titleSection}>
          <div className={styles.titleSectionChild} />
          <b className={styles.popularPlaces}>Popular Places</b>
        </div>
        <div className={styles.articleSideCard}>
          <div className={styles.articleSideCardChild} />
          <img
            className={styles.imageArticleIcon}
            alt=""
            src="/image-article@2x.png"
          />
          <b className={styles.manali}>Manali</b>
          <div className={styles.august2022}>22 August 2022</div>
        </div>
        <div className={styles.articleSideCard1}>
          <div className={styles.articleSideCardChild} />
          <img
            className={styles.imageArticleIcon}
            alt=""
            src="/image-article1@2x.png"
          />
          <b className={styles.manali}>Kasi in India</b>
          <div className={styles.august2022}>12 June 2021</div>
        </div>
        <div className={styles.articleSideCard2}>
          <div className={styles.articleSideCardChild} />
          <img
            className={styles.imageArticleIcon}
            alt=""
            src="/image-article2@2x.png"
          />
          <b className={styles.manali}>maldives</b>
          <div className={styles.august2022}>21 February 2022</div>
        </div>
      </div>
      <div className={styles.sectionSideCategories}>
        <div className={styles.titleSection}>
          <div className={styles.titleSectionChild} />
          <b className={styles.category}>Category</b>
        </div>
        <div className={styles.label}>
          <div className={styles.label1}>{`> Label 1 `}</div>
          <div className={styles.div}>(1)</div>
        </div>
        <div className={styles.label2}>
          <div className={styles.div1}>(2)</div>
          <div className={styles.label21}>{`> Label 2`}</div>
        </div>
      </div>
      <div className={styles.sectionCard}>
        <div className={styles.cardImageBig}>
          <div className={styles.cardImageBigChild} />
          <div className={styles.text2}>
            <b className={styles.parisTour}>Paris tour</b>
            <div className={styles.inLabel1}>In Label</div>
            <div className={styles.byTraveller1}>By Traveller</div>
            <div
              className={styles.parisTheCity}
            >{`Paris, the City of Light, captivates with its timeless elegance and cultural allure. Home to iconic landmarks like the Eiffel Tower and Louvre Museum, `}</div>
            <div className={styles.august20221}>25 August 2022</div>
          </div>
          <img
            className={styles.bannerImageIcon1}
            alt=""
            src="/banner-image1@2x.png"
          />
        </div>
        <div className={styles.cardImageBig1}>
          <div className={styles.cardImageBigChild} />
          <div className={styles.text3}>
            <b className={styles.chinaWall}>China Wall</b>
            <div className={styles.inLabel2}>In Label</div>
            <div className={styles.byTraveller2}>By Traveller</div>
            <div className={styles.parisTheCity}>
              The Great Wall of China, a marvel of ancient engineering, spans
              over 13,000 miles across northern China. Built to protect against
              invasions,.
            </div>
            <div className={styles.april2022}>15 April 2022</div>
          </div>
          <img
            className={styles.bannerImageIcon1}
            alt=""
            src="/banner-image2@2x.png"
          />
        </div>
        <div className={styles.cardImageBig2}>
          <div className={styles.cardImageBigChild} />
          <div className={styles.text4}>
            <b className={styles.parisTour}>Taj Mahal</b>
            <div className={styles.inLabel1}>In Label</div>
            <div className={styles.byTraveller1}>By Traveller</div>
            <div className={styles.parisTheCity}>
              The Taj Mahal, a timeless marvel in Agra, India, stands as an ode
              to love and architectural brilliance. Crafted in white marble,
              this symmetrical masterpiece.
            </div>
            <div className={styles.june2022}>30 June 2022</div>
          </div>
          <img
            className={styles.bannerImageIcon1}
            alt=""
            src="/banner-image3@2x.png"
          />
        </div>
        <div className={styles.cardImageBig3}>
          <div className={styles.cardImageBigChild} />
          <div className={styles.text5}>
            <b className={styles.chinaWall}>Himalayas</b>
            <div className={styles.inLabel2}>In Label</div>
            <b className={styles.byTraveller4}>By Traveller</b>
            <div className={styles.theHimalayasEarths}>
              The Himalayas, Earth's majestic crown, stand as a testament to
              nature's grandeur. This formidable mountain range, spanning five
              countries, boasts the world's highest peak.
            </div>
            <div className={styles.april2022}>22 January 2022</div>
          </div>
          <img
            className={styles.bannerImageIcon1}
            alt=""
            src="/banner-image4@2x.png"
          />
        </div>
        <div className={styles.titleSection1}>
          <div className={styles.titleSectionItem} />
          <b className={styles.latestBlogPosts}>Latest Blog Posts</b>
          <div className={styles.destinations1}>Destinations</div>
        </div>
      </div>
      <div className={styles.footer}>
        <div className={styles.footerChild} />
        <div className={styles.copyrighttraveller}>Copyright@Traveller</div>
      </div>
    </div>
  );
};

export default Desktop;
